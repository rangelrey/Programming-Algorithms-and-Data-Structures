public interface Contentable{
    public String getContent();
 //this interface ensures the existence of getContent() in all the sublasses
 //otherwise the algorithm cannot work
}
