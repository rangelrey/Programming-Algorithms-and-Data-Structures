public interface Contentable{
    public String getContent();
 
}
