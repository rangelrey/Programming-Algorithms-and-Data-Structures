
public class AllTestsRunner
{
    public static void main(){
     
     System.out.println("\n- Testing Text class"); 
     TestText.main();   
     System.out.println("\n- Testing Visual class"); 
     TestVisual.main();
     System.out.println("\n- Testing Audible class"); 
     TestAudible.main();
     System.out.println("\n- Testing Graph class"); 
     TestGraph.main();
     System.out.println("\n- Testing GNode class"); 
     TestGNode.main();
     System.out.println("\n- Testing Stack class"); 
     TestStack.main();
     
        
    }
}
